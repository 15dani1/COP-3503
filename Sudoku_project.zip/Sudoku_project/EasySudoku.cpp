
#include "sudoku.h"
#include <fstream>
#include <iostream>

int highScore1 = 0;//my code
int highScore2 = 0;//my code
int highScore3 = 0;//my code
int highScore4 = 0;//my code
int highScore5 = 0;//my code

int Sudoku::easySudoku1(){

    const int rows = 15;
    const int columns = 15;

    cout << "          Easy Puzzle 1            " << endl;
    cout << "" << endl;

    string sudokuEasy1 [rows][columns] =
            {
                    {" ", " ", " ", "A", "B", "C", " ", "D", "E", "F", " ", "G", "H", "I", " "},
                    {" ", " ", "+", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "+"},
                    {" ", "1", "|", "9", "1", " ", "|", "7", " ", " ", "|", " ", " ", " ", "|"},
                    {" ", "2", "|", " ", "3", "2", "|", "6", " ", "9", "|", " ", "8", " ", "|"},
                    {" ", "3", "|", " ", " ", "7", "|", " ", "8", " ", "|", "9", " ", " ", "|"},
                    {" ", " ", "|", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "|"},
                    {" ", "4", "|", " ", "8", "6", "|", " ", "3", " ", "|", "1", "7", " ", "|"},
                    {" ", "5", "|", "3", " ", " ", "|", " ", " ", " ", "|", " ", " ", "6", "|"},
                    {" ", "6", "|", " ", "5", "1", "|", " ", "2", " ", "|", "8", "4", " ", "|"},
                    {" ", " ", "|", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "|"},
                    {" ", "7", "|", " ", " ", "9", "|", " ", "5", " ", "|", "3", " ", " ", "|"},
                    {" ", "8", "|", " ", "2", " ", "|", "3", " ", "1", "|", "4", "9", " ", "|"},
                    {" ", "9", "|", " ", " ", " ", "|", " ", " ", "2", "|", " ", "6", "1", "|"},
                    {" ", " ", "+", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "+"},
            };

    for(int i=0; i < 15; i++){

        for(int j=0; j < 15; j++) {

            cout << sudokuEasy1[i][j] << " ";
        }
        cout << endl;
    }

    cout << "Please Enter the Letter Position of the Grid in which you would like to fill a value: ";
    string letterValue;
    cin >> letterValue;
    cout << "";
    cout << "Please Enter the Number Position of the Grid in which you would like to fill a value: ";
    string numberValue;
    cin >> numberValue;
    cout << "";
    cout << "Please Enter the Sudoku number in the desired position: ";
    string sudokuValue;
    cin >> sudokuValue;

    int myLetterVal = stoi(letterValue);
    int myNumberVal = stoi(numberValue);

    sudokuEasy1[myNumberVal][myLetterVal] = sudokuValue;

    for(int i=0; i < 15; i++){

        for(int j=0; j < 15; j++) {

            cout << sudokuEasy1[i][j] << " ";
        }
        cout << endl;
    }

}

int main(){

    Sudoku sudoku; //my code
    sudoku.saveHighscore(1000); //my code
    sudoku.saveHighscore(1075);//my code
    sudoku.saveHighscore(1069);//my code
    sudoku.saveHighscore(1200);//my code
    sudoku.saveHighscore(1000);//my code
    sudoku.readHighscore();//my code
    sudoku.easySudoku1();
    return 0;
}


void Sudoku::saveHighscore(int score){//my code

    readHighscore();
    if(score >= highScore1){
        highScore5 = highScore4;
        highScore4 = highScore3;
        highScore3 = highScore2;
        highScore2 = highScore1;
        highScore1 = score;
    } else if(score >= highScore2){
        highScore5 = highScore4;
        highScore4 = highScore3;
        highScore3 = highScore2;
        highScore2 = score;
    } else if(score >= highScore3){
        highScore5 = highScore4;
        highScore4 = highScore3;
        highScore3 = score;
    }else if(score >= highScore4){
        highScore5 = highScore4;
        highScore4 = score;
    }else if(score >= highScore5){
        highScore5 = score;
    } else {

    }
    std::ofstream openfile("/Users/yosh/CLionProjects/Sudoku_project/highscoreList");
    if(openfile.is_open()) {
        int i = 0;
        bool randBool = true;
        while (!openfile.eof() && randBool) {
            i++;
            switch (i) {
                case 1:
                    openfile << highScore1 << std::endl;
                    break;
                case 2:
                    openfile << highScore2 << std::endl;
                    break;
                case 3:
                    openfile << highScore3 << std::endl;
                    break;
                case 4:
                    openfile << highScore4 << std::endl;
                    break;
                case 5:
                    openfile << highScore5 << std::endl;
                    break;
                default:
                    randBool = false;
                    break;
            }
        }
    }
}
void Sudoku::readHighscore(){//my code

    std::ifstream openfile("/Users/yosh/CLionProjects/Sudoku_project/highscoreList");
    if(openfile.is_open())
    {
        int i = 0;
        bool randBool2 = true;
        while(!openfile.eof() && randBool2) {
            i++;
            switch(i){
                case 1:
                    openfile >> highScore1;
                    break;
                case 2:
                    openfile >> highScore2;
                    break;
                case 3:
                    openfile >> highScore3;
                    break;
                case 4:
                    openfile >> highScore4;
                    break;
                case 5:
                    openfile >> highScore5;
                    break;
                default:
                    randBool2 = false;
                    break;
            }
        }
        printHighscore();
    }
}
void Sudoku::printHighscore(){//my code
    std::cout<<highScore1<<std::endl;
    std::cout<<highScore2<<std::endl;
    std::cout<<highScore3<<std::endl;
    std::cout<<highScore4<<std::endl;
    std::cout<<highScore5<<std::endl;
}